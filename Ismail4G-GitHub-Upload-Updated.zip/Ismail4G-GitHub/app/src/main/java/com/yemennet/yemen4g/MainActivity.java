package com.yemennet.yemen4g;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText etNum;
    private Button btnQuery;
    private ProgressBar bar;
    private WebView webView;
    private TextView status;
    private YemenNetEngine engine;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        etNum = findViewById(R.id.etNum);
        btnQuery = findViewById(R.id.btnQuery);
        bar = findViewById(R.id.bar);
        webView = findViewById(R.id.webView);
        status = findViewById(R.id.status);
        engine = new YemenNetEngine(this, webView);
        btnQuery.setOnClickListener(v -> {
            String number = etNum.getText().toString().trim();
            if (number.length() < 7) {
                etNum.setError("أدخل رقم المودم بصورة صحيحة");
                return;
            }
            bar.setVisibility(View.VISIBLE);
            btnQuery.setEnabled(false);
            status.setText("جارٍ فتح خدمة يمن نت الرسمية…");
            engine.load(new YemenNetEngine.Listener() {
                @Override public void onPageLoaded() {
                    bar.setVisibility(View.GONE);
                    btnQuery.setEnabled(true);
                    status.setText("تم تحميل الموقع الرسمي. أكمل الاستعلام داخل الصفحة أدناه؛ لا تُعرض نتيجة مختلقة.");
                    Toast.makeText(MainActivity.this, "أكمل إدخال رمز التحقق والاستعلام داخل صفحة يمن نت", Toast.LENGTH_LONG).show();
                }
                @Override public void onError(String message) {
                    bar.setVisibility(View.GONE);
                    btnQuery.setEnabled(true);
                    status.setText(message);
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
