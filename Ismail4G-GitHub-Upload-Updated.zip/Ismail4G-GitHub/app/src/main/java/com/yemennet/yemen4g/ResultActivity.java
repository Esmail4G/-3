package com.yemennet.yemen4g;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
/** Reserved for a future verified results screen; no fake balance is displayed. */
public class ResultActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle state) { super.onCreate(state); setContentView(R.layout.activity_result); }
}
