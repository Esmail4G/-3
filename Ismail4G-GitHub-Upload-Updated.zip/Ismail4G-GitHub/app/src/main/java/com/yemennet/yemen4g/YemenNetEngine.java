package com.yemennet.yemen4g;

import android.annotation.SuppressLint;
import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;

public final class YemenNetEngine {
    public static final String TARGET_URL = "https://svc.ptc.gov.ye/4g/";
    private final WebView webView;
    private Listener listener;

    public interface Listener {
        void onPageLoaded();
        void onError(String message);
    }

    @SuppressLint("SetJavaScriptEnabled")
    public YemenNetEngine(Context context, WebView view) {
        webView = view;
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        CookieManager.getInstance().setAcceptCookie(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith(TARGET_URL) && listener != null) listener.onPageLoaded();
            }
            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request,
                    android.webkit.WebResourceError error) {
                if (request.isForMainFrame() && listener != null)
                    listener.onError("تعذر تحميل موقع يمن نت. تحقق من الإنترنت وحاول مجددًا.");
            }
            @Override public void onReceivedSslError(WebView view, android.webkit.SslErrorHandler handler,
                    android.net.http.SslError error) {
                handler.cancel();
                if (listener != null) listener.onError("تعذر التحقق من شهادة أمان موقع يمن نت؛ أوقف التطبيق الاتصال.");
            }
        });
    }

    public void load(Listener callback) {
        listener = callback;
        webView.loadUrl(TARGET_URL);
    }
}
